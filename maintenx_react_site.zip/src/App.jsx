
import React from "react";
import "./styles.css";
import screenshot from "../assets/Screenshot.png";

export default function App(){
  return (
    <div className="app">
      <header className="hero">
        <div className="brand">
          <div className="logo">MX</div>
          <div>
            <h1>MaintenX</h1>
            <div className="tag">Premium Home Appliance Care</div>
          </div>
        </div>
      </header>
      <main className="container">
        <section className="preview">
          <h2>Current site preview (screenshot)</h2>
          <img src={screenshot} alt="screenshot" className="screenshot"/>
        </section>
        <section className="services">
          <h3>Sample Services</h3>
          <ul>
            <li>AC Repair & Service</li>
            <li>Refrigerator Repair</li>
            <li>Electrician</li>
            <li>Washing Machine Repair</li>
          </ul>
        </section>
      </main>
      <footer className="footer">© MaintenX Demo</footer>
    </div>
  );
}
